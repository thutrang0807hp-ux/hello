Hai gói Toolkit đi kèm:
- Toolkit-Installed-Build-Bridge.zip: bản extension cầu nối để cài trên Chrome.
- Toolkit-Installed-Build-Source.zip: mã nguồn tương ứng và giấy phép.
Mã ứng dụng Freelance Desk nằm tại thư mục cha, không cần chép ZIP app cũ.
